#!/bin/bash
read -p "Enter directory name: " dir
mkdir -p "$dir"
echo "Directory '$dir' created."
cd "$dir" || exit
echo "Now inside: $(pwd)"
read -p "Enter filename to create: " fname
touch "$fname"
echo "File '$fname' created."
echo "Appending some text to $fname..."
echo "This is a sample text." >> "$fname"
echo "Final content of $fname:"
cat "$fname"
