#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

#define SIZE 128
#define NAME "/shared_memory"

int main() {
    int shm_fd = shm_open(NAME, O_CREAT | O_RDWR, 0666);
    if (shm_fd == -1) {
        perror("shm_open Failed");
        exit(EXIT_FAILURE);
    }

    if (ftruncate(shm_fd, SIZE) == -1) {
        perror("ftruncate Failed");
        exit(EXIT_FAILURE);
    }

    char* shm_ptr = (char*)mmap(0, SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    if (shm_ptr == MAP_FAILED) {
        perror("mmap Failed");
        exit(EXIT_FAILURE);
    }

    pid_t child = fork();
    if (child == -1) {
        perror("Fork Failed");
        exit(EXIT_FAILURE);
    }

    if (child == 0) {  
        printf("Child process writing to shared memory...\n");
        sprintf(shm_ptr, "Hello, My name is Juzer!");
        printf("Child process wrote: %s\n", shm_ptr);
        printf("\n");
    } else {  
        sleep(2); 
        printf("\n");
        printf("Parent process reading from shared memory...\n");
        printf("Parent process read: %s\n", shm_ptr);
    }

    if (munmap(shm_ptr, SIZE) == -1) {
        perror("munmap");
        exit(EXIT_FAILURE);
    }

    if (close(shm_fd) == -1) {
        perror("close");
        exit(EXIT_FAILURE);
    }

    if (shm_unlink(NAME) == -1) {
        perror("shm_unlink");
        exit(EXIT_FAILURE);
    }

    return 0;
}
