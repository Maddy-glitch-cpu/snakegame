#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>

int main(){
	pid_t child1, child2;
	int sum = 0, avg = 0;
	int pipe1[2], pipe2[2];
	
	if(pipe(pipe1) == -1 || pipe(pipe2) == -1){
		perror("Pipe Failed");
		exit(EXIT_FAILURE);
	}
	
	child1 = fork();
	
	if(child1 == -1){
		perror("Fork Failed");
		exit(EXIT_FAILURE);
	}
	
	if(child1 == 0){
		close(pipe1[0]);
		FILE *fd = fopen("data.txt", "r");
		
		if(fd == NULL){
			perror("Failed Opening");
			exit(EXIT_FAILURE);
		}
		
		int num;
		int sum = 0;
		while(fscanf(fd, "%d", &num) != EOF){
			sum+=num;
		}
		fclose(fd);	
		write(pipe1[1], &sum, sizeof(int));
		close(pipe1[1]);
		exit(0);
	}
	
	child2 = fork();
	
	if(child2 == -1){
		perror("Fork Failed");
		exit(EXIT_FAILURE);
	}
	
	if(child2 == 0){
		close(pipe2[0]);
		FILE *fd = fopen("data.txt", "r");
		
		if(fd == NULL){
			perror("Failed Opening");
			exit(EXIT_FAILURE);
		}
		
		int num;
		int sum = 0;
		int n = 0;
		while(fscanf(fd, "%d", &num) != EOF){
			sum+=num;
			n++;
		}
		fclose(fd);
		int avg = sum/n;
		
		write(pipe2[1], &avg, sizeof(int));
		close(pipe2[1]);
		exit(0);
	}
	
	wait(NULL);
	wait(NULL);
	
	close(pipe1[1]);
	close(pipe2[1]);
	
	read(pipe1[0], &sum, sizeof(int));
	read(pipe2[0], &avg, sizeof(int));
	
	close(pipe1[0]);
	close(pipe2[0]);
	
	printf("Sum: %d \n Average: %d \n", sum, avg);
	
	return 0;
}