#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>

#define NAME "/tmp/my_pracice_pipe"
#define BUFFER_SIZE 1024
int main(){
    mkfifo(NAME, 0666);

    int fd = open(NAME, O_RDWR);

    if(fd == -1){
        perror("OPENING FAILED");
        exit(EXIT_FAILURE);
    }

    pid_t child = fork();

    if(child == -1){
        perror("FORK FAILED");
        exit(EXIT_FAILURE);
    }

    if(child == 0){

        sleep(2);

        char message_c[BUFFER_SIZE];
        
        read(fd, message_c, BUFFER_SIZE );

        printf("Message Received: \n%s", message_c);

        exit(0);

    }
    else{

        char message_p[] = "My name is Juzer\n";

        write(fd, message_p, strlen(message_p)+1);

        wait(NULL);
    }

    close(fd);

    unlink(NAME);

    return 0;
}