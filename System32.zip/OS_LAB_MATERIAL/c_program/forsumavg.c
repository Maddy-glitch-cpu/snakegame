#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>



int main(){
// 0 read 1 write
	pid_t child[2];
	int pipe0[2], pipe1[2];
	int sum , avg;
	
	if(pipe(pipe0) == -1 || pipe(pipe1) == -1){
		perror("Pipe Failed");
		exit(EXIT_FAILURE);
	}
	
	for(int i=0; i<2; i++){
		child[i] = fork();
		
		if(child[i] == -1){
			perror("Fork Failed");
			exit(EXIT_FAILURE);
		}
		
		if(child[i] == 0){
			if(i == 0){
				close(pipe0[0]);
				FILE *ptr = fopen("data.txt","r");
				if(ptr == NULL){
					perror("Failed Opening File");
					exit(1);
				}
				int num, sum = 0;
				while(fscanf(ptr, "%d", &num) != EOF){
					sum += num;
				}
				
				fclose(ptr);
				
				write(pipe0[1], &sum, sizeof(int));
				close(pipe0[1]);
				exit(0);
			}
			if(i == 1){
				close(pipe1[0]);
				FILE *ptr = fopen("data.txt","r");
				if(ptr == NULL){
					perror("Failed Opening File");
					exit(1);
				}
				int num, sum = 0, n = 0;
				while(fscanf(ptr, "%d", &num) != EOF){
					sum += num;
					n++;
				}
				int avg = sum/n;
				
				fclose(ptr);
				
				write(pipe1[1], &avg, sizeof(int));
				close(pipe1[1]);
				exit(0);
			}
		}
		
	}
	
	close(pipe0[1]);
	close(pipe1[1]);
			
	wait(NULL);
	wait(NULL);
			
	read((pipe0[0]), &sum, sizeof(int));
	read((pipe1[0]), &avg, sizeof(int));
			
	close(pipe0[0]);
	close(pipe1[0]);
			
	printf("Sum: %d, Average: %d", sum, avg);
	
	return 0;

}