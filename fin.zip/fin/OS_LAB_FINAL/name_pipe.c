#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <errno.h>
#include <sys/stat.h>
#include <string.h>
#include <fcntl.h>
#include <stdlib.h>

#define name "/tmp/my_pipe_file"
#define size 2048
int main()
{
    mkfifo(name, 0666);
    int fd = open(name, O_RDWR);
    if (fd == -1)
    {
        perror("Open failed");
        exit(EXIT_FAILURE);
    }
    pid_t child = fork();
    if (child == -1)
    {
        perror("fork failed");
        exit(EXIT_FAILURE);
    }
    if (child == 0)
    {
        char *msg = "Hello Juzer,";
        write(fd, msg, strlen(msg) + 1);
    }
    else
    {
        char reply[size];
        read(fd, reply, 2048);
        printf("Message from child: %s\n", reply);
        wait(NULL);
    }
    close(fd);
    unlink(name);
}