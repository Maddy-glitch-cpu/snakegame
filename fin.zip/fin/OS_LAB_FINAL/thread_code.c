#include <pthread.h>
#include <stdio.h>

void *thread_func(void *arg){
    int num = *(int *)arg;
    num++;
    for(int i =1; i<11; i++)
        printf("%d x %d: %d \n", num, i, num*i);
}

int main(){
    pthread_t t1, t2;
    int id[2] = {1,2};
    
    pthread_create(&t1, NULL, thread_func, &id[0]);
    pthread_create(&t2, NULL, thread_func, &id[1]);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    return 0;
}