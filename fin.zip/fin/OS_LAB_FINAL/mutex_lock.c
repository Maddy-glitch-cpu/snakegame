#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

pthread_mutex_t mutex;
int counter = 0;

void *thread_func(void *arg){
    int id = *(int *)arg;

    for(int i=0; i<5; i++){
        pthread_mutex_lock(&mutex);
        counter ++;
        printf("Thread %d : Counter %d\n", id, counter);
        pthread_mutex_unlock(&mutex);
        sleep(2);
    }
}

int main(){
    pthread_t thread[3];
    int id[3] = {1,2,3};

    pthread_mutex_init(&mutex, NULL);

    for(int i=0; i<3; i++)
    pthread_create(&thread[i], NULL, thread_func, &id[i]);

    for(int i=0; i<3; i++)
    pthread_join(thread[i], NULL);

    printf("\nCounter Value: %d\n", counter);

    pthread_mutex_destroy(&mutex);
}