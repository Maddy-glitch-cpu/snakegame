#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>


int main(){
    int ptc[2], ctp[2];

    if(pipe(ptc) == -1 || pipe(ctp) == -1){
        perror("pipe failed");
        exit(EXIT_FAILURE);
    }

    pid_t child = fork();

    if(child == -1){
        perror("fork failed");
        exit(EXIT_FAILURE);
    }

    if (child == 0){
        close(ptc[1]);
        close(ctp[0]);

        char msg[2048];

        read(ptc[0], msg, 2048);
        printf("Child Received : %s\n", msg);
        close(ptc[0]);
        char *reply = "message received from child";
        write(ctp[1], reply, strlen(reply)+1);

    }
    else{
        close(ptc[0]);
        close(ctp[1]);
        char *msg = "Hello Msg from Parent , Juzer";
        write(ptc[1], msg, strlen(msg)+1);   
        close(ptc[1]);
        wait(NULL);
        char reply[2048];
        read(ctp[0], reply, 2048);
        printf("Parent MSG Received: %s\n", reply);
        
    }

    return 0;
}
