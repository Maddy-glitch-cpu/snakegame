#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define BUFFER_SIZE 3
#define PRODUCER_COUNT 2
#define CONSUMER_COUNT 2
#define ITEMS_PER_PRODUCER 5

int buffer[BUFFER_SIZE];
int in = 0, out = 0;

pthread_mutex_t mutex;
sem_t empty, full;

void* producer(void* arg) {
    int id = *(int*)arg;
    for (int i = 0; i < ITEMS_PER_PRODUCER; i++) {
        int item = id * 100 + i;

        sem_wait(&empty);
        pthread_mutex_lock(&mutex);

        buffer[in] = item;
        printf("Producer %d produced %d at buffer[%d]\n", id, item, in);
        in = (in + 1) % BUFFER_SIZE;

        pthread_mutex_unlock(&mutex);
        sem_post(&full);

        sleep(1); // simulate production time
    }
    return NULL;
}

void* consumer(void* arg) {
    int id = *(int*)arg;
    for (int i = 0; i < (PRODUCER_COUNT * ITEMS_PER_PRODUCER) / CONSUMER_COUNT; i++) {
        sem_wait(&full);
        pthread_mutex_lock(&mutex);

        int item = buffer[out];
        printf("Consumer %d consumed %d from buffer[%d]\n", id, item, out);
        out = (out + 1) % BUFFER_SIZE;

        pthread_mutex_unlock(&mutex);
        sem_post(&empty);

        sleep(1); // simulate consumption time
    }
    return NULL;
}

int main() {
    pthread_t prod[PRODUCER_COUNT], cons[CONSUMER_COUNT];
    int ids[PRODUCER_COUNT + CONSUMER_COUNT];

    pthread_mutex_init(&mutex, NULL);
    sem_init(&empty, 0, BUFFER_SIZE);
    sem_init(&full, 0, 0);

    // Create producer threads
    for (int i = 0; i < PRODUCER_COUNT; i++) {
        ids[i] = i + 1;
        pthread_create(&prod[i], NULL, producer, &ids[i]);
    }

    // Create consumer threads
    for (int i = 0; i < CONSUMER_COUNT; i++) {
        ids[PRODUCER_COUNT + i] = i + 1;
        pthread_create(&cons[i], NULL, consumer, &ids[PRODUCER_COUNT + i]);
    }

    // Join threads
    for (int i = 0; i < PRODUCER_COUNT; i++) pthread_join(prod[i], NULL);
    for (int i = 0; i < CONSUMER_COUNT; i++) pthread_join(cons[i], NULL);

    pthread_mutex_destroy(&mutex);
    sem_destroy(&empty);
    sem_destroy(&full);
    return 0;
}
