#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <errno.h>

#define size 128
#define name "/my_shared_memeory"

int main(){
    int shm_fd = shm_open(name, O_CREAT | O_RDWR, 0666);
    if (shm_fd == -1){
        perror("Openning Failed");
        exit(EXIT_FAILURE);
    }
    if (ftruncate(shm_fd, size) == -1){
        perror("Ftruncate Failed");
        exit(EXIT_FAILURE);
    }
    char *shm_ptr = (char *)mmap(0, size, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    if (shm_ptr == MAP_FAILED)
    {
        perror("MAP FAILED");
        exit(EXIT_FAILURE);
    }

    pid_t child = fork();

    if(child == -1){
        perror("Fork Failed");
        exit(EXIT_FAILURE);
    }

    if (child == 0){
        char buffer[2048];
        strcpy(buffer, shm_ptr);
        printf("Message Reveivec: %s\n", buffer);
    }
    else{
        char *msg = "My name is Juzer, Nice to Meet you";
        strcpy(shm_ptr, msg);
    }

    munmap(shm_ptr, size);
    close(shm_fd);
    unlink(name);
    
}
