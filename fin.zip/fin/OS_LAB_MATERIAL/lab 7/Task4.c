#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>

int main(){
    pid_t child[4];

    for(int i=0; i<4; i++){
        child[i] = fork();

        if(child[i] == -1){
            perror("Fork failed");
            exit(EXIT_FAILURE);
        }

        if(child[i] == 0){
            if(i ==0){
                execlp("ls", "ls", NULL);
            }
            if(i ==1){
                execlp("ps", "ps", NULL);
            }
            if(i ==2){
                execlp("whereis", "whereis", "gcc", NULL);
            }
            if(i ==3){
                execlp("mkdir", "mkdir", "Juzer", NULL);
            }
            perror("execlp failed");
            exit(EXIT_FAILURE);
        }
    }

    for(int i=0; i<4; i++){
        wait(NULL);
    }
    printf("\nAll Child Process Terminated\n");

    return 0;
}