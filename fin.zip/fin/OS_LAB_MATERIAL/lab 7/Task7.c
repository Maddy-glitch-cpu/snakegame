#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <string.h>

int main() {
    int num;
    printf("Enter a Number: "); 
    scanf("%d", &num);

    int ptc[2], ctp[10][2];

    if (pipe(ptc) == -1) {
        perror("Pipe Failed");
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < 10; i++) {
        if (pipe(ctp[i]) == -1) {
            perror("Pipe Failed");
            exit(EXIT_FAILURE);
        }
    }

    pid_t child = fork();

    if (child == -1) {
        perror("Fork Failed");
        exit(EXIT_FAILURE);
    }

    if (child == 0) {  
        close(ptc[1]); 
        int n;
        read(ptc[0], &n, sizeof(int));
        close(ptc[0]); 

        int arr[10];
        int count = 0;
        int temp = n;

        while (temp > 0) {
            arr[count] = temp % 10;
            temp /= 10;
            count++;
        }

        for (int i = 0; i < count / 2; i++) {
            int temp = arr[i];
            arr[i] = arr[count - i - 1];
            arr[count - i - 1] = temp;
        }

        for (int i = 0; i < count; i++) {
            close(ctp[i][0]); 
            write(ctp[i][1], &arr[i], sizeof(int)); 
            close(ctp[i][1]); 
        }

        exit(0);
    } else {  
        close(ptc[0]); 
        write(ptc[1], &num, sizeof(int));
        close(ptc[1]); 

        wait(NULL);

        int product = 1;
        int digit;
        for (int i = 0; i < 10; i++) {
            close(ctp[i][1]); 
            if (read(ctp[i][0], &digit, sizeof(int)) > 0) {
                product *= digit;
            }
            close(ctp[i][0]); 
        }

        printf("The Product is: %d\n", product);
    }

    return 0;
}
