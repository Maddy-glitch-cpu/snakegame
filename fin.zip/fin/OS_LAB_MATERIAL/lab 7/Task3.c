#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdbool.h>
#include <errno.h>

int factorial(int n){
    if(n == 0 || n == 1) return 1;
    return n * factorial(n - 1);
}

void prime_logic(int n){
    printf("Prime Number till %d are: ", n);
    for (int i = 2; i <= n; i++) {
        bool isPrime = true;
        for (int j = 2; j < i; j++) {
            if (i % j == 0) {
                isPrime = false;
                break;
            }
        }
        if (isPrime)
            printf("%d ", i);
    }
    printf("\n");
}

void fibo(int n){
    int first = 0, second = 1;
    printf("Fibonacci Series of %d terms: ", n);
    for(int i = 0; i < n; i++){
        printf("%d ", first);
        int sum = first + second;
        first = second;
        second = sum;
    }
    printf("\n");
}

int main(int argc, char* argv[]){
    if(argc < 4){
        fprintf(stderr, "Usage: %s num1 num2 num3\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    int n1 = atoi(argv[1]);
    int n2 = atoi(argv[2]);
    int n3 = atoi(argv[3]);

    pid_t child1 = fork();

    if(child1 == -1){
        perror("Fork failed");
        exit(EXIT_FAILURE);
    }

    if(child1 == 0){
        int fac = factorial(n1);
        printf("The Factorial of %d is: %d\n", n1, fac);
        exit(0);
    } else {
        pid_t child2 = fork();

        if(child2 == -1){
            perror("Fork failed");
            exit(EXIT_FAILURE);
        }

        if(child2 == 0){
            fibo(n2);
            exit(0);
        } else {
            pid_t child3 = fork();

            if(child3 == -1){
                perror("Fork failed");
                exit(EXIT_FAILURE);
            }

            if(child3 == 0){
                prime_logic(n3);
                exit(0);
            }
        }
    }

    wait(NULL);
    wait(NULL);
    wait(NULL);

    printf("\nAll Child Process Terminated Successfully.\n");

    return 0;
}
