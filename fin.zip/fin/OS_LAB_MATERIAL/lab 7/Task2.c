#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdbool.h>
#include <ctype.h>

int main(){
	
	int fd = open("input.txt", O_RDONLY);
	
	if(fd == -1){
		perror("Failed Opening");
		exit(EXIT_FAILURE);
	}
	
	int buffer_size = 1024;
	char buffer[buffer_size];
	int bytesread;
	int word_count = 0;
	
	while((bytesread = read(fd, buffer, buffer_size)) > 0){
		for(int i=0; i<bytesread; i++){
			if(isspace(buffer[i])){
				word_count++;
			}
		}	
	}
	
	close(fd);
	
	printf("Total Word Count is %d", word_count);
	
	return 0;
}