#!/bin/bash
create_user_account() {
    read -p "Enter username: " username
    sudo useradd "$username"
    sudo passwd "$username"
}
create_directories() {
    read -p "Enter parent directory name: " dir
    mkdir -p "$dir"/{docs,images,backup}
    echo "Subdirectories created inside $dir"
}
list_files_hidden_unhidden() {
    dir=$1
    if [ -d "$dir" ]; then
        echo "All files in $dir:"
        ls -a "$dir"
    else
        echo "Directory doesn't exist."
    fi
}
create_user_account
create_directories
list_files_hidden_unhidden "$1"
