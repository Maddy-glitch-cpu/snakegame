#!/bin/bash
create_book_directory() {
    mkdir -p ~/Desktop/Books
    read -p "Enter number of books: " count
    for ((i=1; i<=count; i++))
    do
        read -p "Book Name: " name
        read -p "Author: " author
        read -p "Price: " price
        read -p "Publication: " pub
        read -p "Stock: " stock
        echo -e "Book: $name\nAuthor: $author\nPrice: $price\nPublication: $pub\nStock: $stock" > ~/Desktop/Books/"$name".txt
    done
}
list_books() {
    echo "Books in ~/Desktop/Books:"
    ls ~/Desktop/Books
}
create_book_directory
list_books
