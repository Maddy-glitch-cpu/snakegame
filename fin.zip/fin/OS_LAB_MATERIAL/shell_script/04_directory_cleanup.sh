#!/bin/bash
read -p "Enter directory path: " dir
read -p "Delete files older than how many days? " days
if [ ! -d "$dir" ]; then
    echo "Directory not found!"
    exit 1
fi
old_files=$(find "$dir" -type f -mtime +$days)
empty_dirs=$(find "$dir" -type d -empty)
echo "Deleting old files..."
deleted_files=$(echo "$old_files" | wc -l)
echo "$old_files" | xargs -r rm -f
echo "Deleting empty directories..."
deleted_dirs=$(echo "$empty_dirs" | wc -l)
echo "$empty_dirs" | xargs -r rmdir
echo "$deleted_files files and $deleted_dirs directories deleted."
