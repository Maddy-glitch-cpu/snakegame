#!/bin/bash

if [ $# -ne 2]; then
    echo -e "No Input Given"
    exit 1
else
    num1=$1
    num2=$2

    echo -e "Addition: $((num1 + num2))"
    echo -e "Subtraction: $((num1 - num2))"
    echo -e "Multiplication: $((num1 * num2))"
    echo -e "Division: $((num1 / num2))"
fi