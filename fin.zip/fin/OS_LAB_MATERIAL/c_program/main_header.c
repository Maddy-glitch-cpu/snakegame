#include <stdio.h>
#include "my_header.h"

int main(){
    greet();
    printf("Add 5+6 = %d\n Mul 5x6 = %d", add(5,6), mul(5,6));
    return 0;
}