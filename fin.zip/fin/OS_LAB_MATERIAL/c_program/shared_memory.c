#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/mman.h>

#define NAME "/my_shared_memory"
#define SHARED_MEMORY_SIZE 128

int main() {
    // Create shared memory object
    int shm_fd = shm_open(NAME, O_CREAT | O_RDWR, 0666);
    if (shm_fd == -1) {
        perror("shm_open failed");
        exit(EXIT_FAILURE);
    }

    // Resize shared memory
    if (ftruncate(shm_fd, SHARED_MEMORY_SIZE) == -1) {
        perror("ftruncate failed");
        exit(EXIT_FAILURE);
    }

    // Map shared memory
    char *shm_ptr = (char *) mmap(0, SHARED_MEMORY_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    if (shm_ptr == MAP_FAILED) {
        perror("mmap failed");
        exit(EXIT_FAILURE);
    }

    pid_t child = fork();

    if (child < 0) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    }

    if (child == 0) {
        // Child process - read from shared memory
        sleep(1); // Optional: ensure parent writes first
        printf("Child: Message read from shared memory: %s\n", shm_ptr);

        // Unmap and close
        munmap(shm_ptr, SHARED_MEMORY_SIZE);
        close(shm_fd);
        exit(0);
    } else {
        // Parent process - write to shared memory
        const char *message = "Hello from Parent via Shared Memory!";
        strcpy(shm_ptr, message);

        // Wait for child
        wait(NULL);

        // Cleanup: unmap, close, unlink
        munmap(shm_ptr, SHARED_MEMORY_SIZE);
        close(shm_fd);
        shm_unlink(NAME);
    }

    return 0;
}
