#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]){
	if (argc == 1){
		printf("No Input Given");
		return 1;
	}
	int arr[argc-1];
	for(int i=1; i<argc; i++){
		arr[i-1] = atoi(argv[i]);
	}
	
	int sum = 0;
	int avg;
	int n = 0;
	
	for(int i=0; i<argc-1; i++){
		sum += arr[i];
		n++;
	}
	
	avg = sum/n;
	
	printf("Sum: %d , Average: %d", sum , avg);
	
	return 0;
}
