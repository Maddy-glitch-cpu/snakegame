#include <stdio.h>
#include "my_header.h"

void greet(){
    printf("Hello!, My name is Juzer Abdul Ali\n");
}

int add(int a, int b){
    return a+b;
}

int mul(int a, int b){
    return a*b;
}