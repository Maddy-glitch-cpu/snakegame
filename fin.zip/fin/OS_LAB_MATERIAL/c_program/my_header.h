#ifndef MY_HEADER_H
#define MY_HEADER_H

void greet();
int add(int a, int b);
int mul(int a, int b);

#endif